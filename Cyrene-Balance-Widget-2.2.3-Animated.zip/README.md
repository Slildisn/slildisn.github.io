# Cyrene Balance Widget 2.2.3 (Animated)

[![Listed on DSH Market](https://raw.githubusercontent.com/2BingLing/dsh-market/master/assets/readme/badge-listed-en.svg)](https://dsh.market/)
**New in 2.2.3** — the widget now ships its own font (a rounded handwritten face) and
can be switched between that and the system font from the settings panel. The opening
animation gained a mute switch for quiet launches. Balance figures are drawn in a pink
gradient instead of the old blue. Package size dropped from 30.8 MB to 17.6 MB, which
makes market installs far less likely to arrive incomplete.

**New in 2.2.2** — the greeting picker now avoids repeating the line it played last time (remembered across restarts).

**New in 2.2.1** — the greeting voice can now be controlled line by line: the settings panel lists every line as text
with its own checkbox, so you can turn off any of them (or all of them). The old "帝皇权杖·铁墓" random line has been
replaced, and there are now four random greetings instead of three.


**New in 2.2** — settings toggles for the splash animation and the greeting voice (state kept in `localStorage`),
an idle greeting (20 minutes without input → the widget says a line in a bubble), and the ledger button is now
labelled "Cyrene's ledger" instead of the whale one.

On client startup it plays a full-screen opening animation (`assets/loading.mp4`, 1440p / 60fps, ~20 MB, 13.9 s),
fades out into the UI, and 2.5 seconds later plays "Cyrene's Greeting".

## What this build does

| Item | Details |
|---|---|
| Loading animation | Full-screen `loading.mp4` (2560×1440, H.264, 60fps, ~20 MB) with `object-fit: cover` |
| Audio | Original soundtrack kept at full volume; **linear fade-out over the last 2.2 s** — the sound lasts exactly as long as the animation |
| Exit | Overlay fades out over 900 ms, the page fades in naturally |
| Greeting | **2.5 s after** the fade-out completes, `assets/greeting.wav` (3.58 s) plays together with a short toast |
| Interaction | **No skip button, no fullscreen request, no hiding of window buttons** — just a plain opening animation |
| Fallbacks | Autoplay with sound blocked → retry muted; not playing within 2.6 s → skip; hard release at 20 s |

## The widget itself

- Character: built-in Cyrene sprite (610×610, transparent, bottom-aligned)
- Lines: 25 quotes, font sizes 6/7/8/9, shown at random
- First click: balance panel; next click: a random quote
- Everything else (sound effects, snapping, accounting, bubble editor) comes from `dsh-whale-widget` 0.4.2

## Customising

- **Lines**: right-click the widget → bubble settings; or `BUBBLE_DEFAULT_ITEMS` in `assets/whale-widget.js`; batch via `tools/set-lines.py`
- **Font size**: `tools/resize-lines.py` (edit `SIZE_MAP`, then re-run)
- **Greeting audio**: replace `assets/greeting.wav`, refresh to apply
- **Opening animation**: replace `assets/loading.mp4` (H.264 recommended for widest compatibility)

## Install

`plugin_manager` → `install_bundle`, with `target` set to this directory's absolute path.
The no-animation build lives in `../no-animation/` (package `dsh-cyrene-whale-widget-noanim`). Both share the
`/dsh-whale/*` routes and `$DSH_HOME/.dshw-*.json`, so only one can be enabled at a time.

## Asset credits

Character: Cyrene sticker provided by the user; lines and greeting voice: user-provided;
opening animation: user-provided 4K source, re-encoded to 1440p60 H.264;
upstream `dsh-whale-widget` v0.4.2 (MIT, see `LICENSE` and `README.upstream.md`).

## Installation troubleshooting

The DSH Market installs plugins by cloning the GitHub repository with `pnpm add git+...`.
On slow or unstable connections that clone can stop halfway, which leaves the widget
with missing assets — typically only one broken character image shows up.

If that happens, install manually instead:

1. Download `Cyrene-Balance-Widget-<version>-Animated.zip` from the
   [latest release](https://github.com/sailina-afk/cyrene-balance-widget/releases/latest)
2. Unzip it anywhere
3. In DSH: settings → plugins → install local plugin, pick the unzipped folder
4. Fully quit the client and start it again

The release zip is the same code, just packaged without git history. It downloads as a
single file, so it cannot arrive half-finished.
