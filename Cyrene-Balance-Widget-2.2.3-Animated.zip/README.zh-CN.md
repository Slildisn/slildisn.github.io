# 昔涟余额挂件 2.2（带动画）

[![已收录](https://raw.githubusercontent.com/2BingLing/dsh-market/master/assets/readme/badge-listed-zh.svg)](https://dsh.market/)
**2.2.3 新增**——插件自带一套圆润手写字体，可在设置面板切换「奶酪体 / 系统字体」；开屏动画新增静音开关，夜里启动不吵人；余额数字改为粉色渐变；包体从 30.8 MB 降到 17.6 MB，市场安装更容易装全。


**2.2.2 新增**——问候语音不再连续重复：会记住上一次播的那条，下次从剩下的里抽。

**2.2.1 新增**——问候语音可以逐条开关了：设置面板把每一句的内容以文字列出来，各自一个勾选框，想听哪条勾哪条，
全取消则不播。原来的「帝皇权杖·铁墓」那句已删除并换成新的，随机问候从三条变成四条。


**2.2 新增**——设置面板里加了「开屏动画」「问候语音」两个开关（状态存在 `localStorage`）；
闲置 20 分钟无操作时，挂件会主动弹一次气泡说句话；记账按钮文案由「小鲸鱼记账」改为「昔涟记账」。

> 中文原文备份，英文版见 `README.md`。

打开客户端先播一段全屏开场动画（`assets/loading.mp4`，1440p / 60fps，约 20 MB，13.9 秒），播完淡出进入界面，
再过 2.5 秒播放「昔涟的问候」。

## 这一版的样子

| 项目 | 说明 |
|---|---|
| 加载动画 | 全屏播放 `loading.mp4`（2560×1440，H.264，60fps，约 20 MB），`object-fit: cover` 铺满 |
| 音效 | 保留原声，全程原音量；**最后 2.2 秒线性淡出**，动画多长声音就多长 |
| 结束 | 播完 overlay 900ms 淡出，页面自然渐显 |
| 问候 | 淡出完成 **2.5 秒**后播放 `assets/greeting.wav`（3.58 秒），同时轻提示一句 |
| 交互 | **没有跳过按钮、不请求全屏、不隐藏窗口按钮**——就是纯开场动画 |
| 兜底 | 带声播放被拦→静音重试；2.6 秒没起播（HEVC 解不了）→ 跳过；20 秒强制放行 |

## 挂件本体

- 形象：内置角色昔涟（610×610 透明底、底部对齐）
- 台词：25 句（`E:\昔涟.txt`），字号 6/7/8/9，随机出现
- 首次点击：余额面板；再点：随机台词
- 其余（音效、吸附、记账、泡泡编辑器）沿用 `dsh-whale-widget` 0.4.2

## 改东西

- **台词**：右键挂件 → 泡泡设置；或 `assets/whale-widget.js` 的 `BUBBLE_DEFAULT_ITEMS`；批量用 `tools/set-lines.py`
- **字号**：`tools/resize-lines.py`（改 `SIZE_MAP` 后重跑）
- **问候语音**：替换 `assets/greeting.wav`，刷新即生效
- **开场动画**：替换 `assets/loading.mp4`（建议 H.264，兼容性最好）

## 安装

`plugin_manager` → `install_bundle`，`target` 用本目录绝对路径。
无动画版在 `../no-animation/`（包名 `dsh-cyrene-whale-widget-noanim`），两版共用
`/dsh-whale/*` 路由与 `$DSH_HOME/.dshw-*.json`，同一时间只能启用一个。

## 素材来源

形象：用户提供的昔涟表情图；台词：`E:\昔涟.txt`；问候：`E:\直播录像与素材\昔涟的问候.wav`；
开场动画：`E:\直播录像与素材\昔涟.mp4`；上游 `dsh-whale-widget` v0.4.2（MIT）。

## 装不上怎么办

DSH 插件市场是通过克隆 GitHub 仓库来安装的（`pnpm add git+...`）。网络不稳时克隆可能中断，装出来的插件会缺文件——通常表现为小人图破掉、其他功能都没有。

遇到这种情况改成手动安装：

1. 从 [最新 Release](https://github.com/sailina-afk/cyrene-balance-widget/releases/latest) 下载 `Cyrene-Balance-Widget-<version>-Animated.zip`
2. 解压到任意目录
3. DSH 里：设置 → 插件 → 安装本地插件，选中解压后的目录
4. 完全退出客户端再启动

Release 的 zip 是同一份代码，只是不带 git 历史。它是单文件下载，不会出现装一半的情况。
